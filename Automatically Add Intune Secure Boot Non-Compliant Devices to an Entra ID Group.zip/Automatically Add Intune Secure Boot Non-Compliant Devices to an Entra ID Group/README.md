# Automatically Add Intune Secure Boot Non-Compliant Devices to an Entra ID Group

This Azure Automation runbook keeps an assigned Entra ID security group aligned with the Secure Boot result from a specific Microsoft Intune device compliance policy.

- Adds a Windows device when its Secure Boot setting is `nonCompliant`.
- Removes an existing group member when Secure Boot is `compliant` or `remediated`.
- Takes no action for other states or when the device, policy, or setting cannot be resolved.
- Supports a safe dry-run mode and produces an execution summary.

## How it works

The runbook authenticates to Microsoft Graph with an app registration, validates the configured compliance policy and Secure Boot setting, reads Windows managed devices, and reconciles device membership in the target group.

The compliance policy and setting name are validated with these Microsoft Graph v1.0 endpoints:

http
GET https://graph.microsoft.com/v1.0/deviceManagement/deviceCompliancePolicies/{compliancePolicyId}
GET https://graph.microsoft.com/v1.0/deviceManagement/deviceCompliancePolicies/{compliancePolicyId}/deviceSettingStateSummaries


Per-device policy and setting states are read from Microsoft Graph beta because the runbook needs device-level setting results:

http
GET https://graph.microsoft.com/beta/deviceManagement/managedDevices/{managedDeviceId}/deviceCompliancePolicyStates
GET https://graph.microsoft.com/beta/deviceManagement/managedDevices/{managedDeviceId}/deviceCompliancePolicyStates/{policyStateId}/settingStates


> Microsoft Graph beta APIs can change and are not covered by the same production support guarantees as v1.0 APIs. Test changes before production use.

## Project layout

text
.
|-- src/
|   `-- Invoke-IntuneSecureBootGroupAutomation.ps1
|-- .gitignore
|-- LICENSE
`-- README.md


## Prerequisites

- An Azure Automation account with a PowerShell runbook.
- An Entra ID app registration using client-secret authentication.
- A static/assigned, security-enabled Entra ID group. Dynamic membership groups are not supported.
- An Intune Windows compliance policy that evaluates Secure Boot.
- The `Get-AutomationVariable` command available in the Azure Automation runtime.

## Microsoft Graph application permissions

Grant these **Application** permissions to the app registration and provide tenant admin consent:

- `DeviceManagementConfiguration.Read.All`
- `DeviceManagementManagedDevices.Read.All`
- `GroupMember.ReadWrite.All`
- `Device.ReadWrite.All`

The runbook decodes the access-token role claims at startup and stops if a required permission is missing.

## Configuration

### 1. Create Azure Automation variables

Create the following variables in the Automation account:

| Variable | Purpose | Encrypted |
|---|---|---:|
| `Graph_TenantId` | Entra tenant ID | No |
| `Graph_ClientId` | App registration client ID | No |
| `Graph_ClientSecret` | App registration client secret value | Yes |

Never commit the client secret to this repository.

### 2. Configure the runbook

Edit the configuration block near the top of `src/Invoke-IntuneSecureBootGroupAutomation.ps1`:

```powershell
$TargetGroupId = "00000000-0000-0000-0000-000000000000"
$CompliancePolicyId = "00000000-0000-0000-0000-000000000000"
$CompliancePolicyName = "Windows 11 Compliance Policy"
$SecureBootSettingName = "Windows11CompliancePolicy1.SecureBootEnabled"
$DryRun = $true
```

To discover the setting name, call:

```http
GET https://graph.microsoft.com/v1.0/deviceManagement/deviceCompliancePolicies/{compliancePolicyId}/deviceSettingStateSummaries
```

Use the exact `settingName` value returned for Secure Boot. The runbook also has a fallback match for names ending in `SecureBootEnabled`.

### 3. Test safely

Keep `$DryRun = $true` for the first executions. Review the job output, especially `Would Add (DryRun)` and `Would Remove (DryRun)`. After validating the target devices and group, set `$DryRun = $false` to enable membership changes.

## Deploy to Azure Automation

1. Create a PowerShell runbook in the Automation account.
2. Copy or import `src/Invoke-IntuneSecureBootGroupAutomation.ps1`.
3. Save and publish the runbook.
4. Start a test job with dry-run enabled.
5. Review the complete summary and resolve any missing-policy, missing-setting, or unresolved-device entries.
6. Disable dry-run only after the results are correct.
7. Optionally attach a schedule after a successful production test.

## Behavior and safeguards

- Graph pagination is followed automatically.
- HTTP 429 and temporary 5xx failures are retried with exponential backoff.
- The target group must be a static, security-enabled Entra group.
- Device-level Secure Boot results are cached during each run.
- Devices are never removed for unknown, error, or unsupported setting states.
- An Intune device must resolve to an Entra device before membership is changed.

## Security recommendations

- Store `Graph_ClientSecret` as an encrypted Automation variable.
- Rotate the secret regularly and monitor its expiration date.
- Limit access to the Automation account and target group.
- Review Azure Automation job logs and Entra audit logs.
- Consider migrating to a managed identity if your environment supports the required Microsoft Graph application permissions and assignment process.

## License

Released under the [MIT License](LICENSE).
