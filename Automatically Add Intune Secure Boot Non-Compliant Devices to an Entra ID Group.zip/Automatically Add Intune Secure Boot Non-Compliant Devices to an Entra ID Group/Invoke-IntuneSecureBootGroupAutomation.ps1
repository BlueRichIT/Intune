<#
===============================================================================
Intune Secure Boot Compliance -> Entra ID Group Automation
===============================================================================

Authentication:
    App Registration + Azure Automation Variables

Automation Variables:
    Graph_TenantId
    Graph_ClientId
    Graph_ClientSecret

Compliance Policy:
    Windows11CompliancePolicy1

Compliance Policy ID:
   xxxxxxxxxxxxxxxxxxxxxxxxxxxxx

Secure Boot Setting:
    Windows11CompliancePolicy1.SecureBootEnabled

Logic:

    Secure Boot = nonCompliant
        -> ADD device to Entra Security Group

    Secure Boot = compliant / remediated
        -> REMOVE device from Entra Security Group

    Other states
        -> NO ACTION

Required Microsoft Graph APPLICATION Permissions:

    DeviceManagementConfiguration.Read.All
    DeviceManagementManagedDevices.Read.All
    GroupMember.ReadWrite.All
    Device.ReadWrite.All

IMPORTANT:

    First Test:
        $DryRun = $true

    Production:
        $DryRun = $false

===============================================================================
#>

$ErrorActionPreference = "Stop"


# =============================================================================
# CONFIGURATION
# =============================================================================

# Target Static / Assigned Entra Security Group Object ID
$TargetGroupId = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"


# Exact Intune Compliance Policy ID
$CompliancePolicyId =
    "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"


# Exact Compliance Policy Name
$CompliancePolicyName =
    "xxxxxxxxxxxxxxxxxxxxxxxxxxx"


# Exact Secure Boot setting returned by your tenant
$SecureBootSettingName =
    "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"


# Safe test mode
$DryRun = $false


# =============================================================================
# COUNTERS
# =============================================================================

$TotalManagedDevices      = 0
$WindowsDevices           = 0
$OverallNonCompliant      = 0

$SecureBootNonCompliant   = 0
$SecureBootCompliant      = 0

$AddedCount               = 0
$RemovedCount             = 0
$WouldAddCount            = 0
$WouldRemoveCount         = 0

$AlreadyMemberCount       = 0
$AlreadyOutsideCount      = 0

$PolicyNotFoundCount      = 0
$SettingNotFoundCount     = 0
$UnresolvedCount          = 0
$NoActionCount            = 0
$ErrorCount               = 0


# =============================================================================
# LOGGING
# =============================================================================

function Write-Log {

    param (

        [ValidateSet(
            "INFO",
            "SUCCESS",
            "WARNING",
            "ERROR"
        )]
        [string]$Level = "INFO",

        [Parameter(Mandatory)]
        [string]$Message
    )

    $TimeStamp =
        Get-Date -Format "yyyy-MM-dd HH:mm:ss"

    Write-Output "$TimeStamp [$Level] $Message"
}


# =============================================================================
# GRAPH REQUEST
# =============================================================================

function Invoke-GraphRequest {

    param (

        [Parameter(Mandatory)]
        [string]$Uri,

        [ValidateSet(
            "GET",
            "POST",
            "DELETE",
            "PATCH"
        )]
        [string]$Method = "GET",

        $Body = $null,

        [switch]$AllowNotFound,

        [int]$MaxRetries = 6
    )


    for (
        $Attempt = 1;
        $Attempt -le $MaxRetries;
        $Attempt++
    ) {

        try {

            $Parameters = @{

                Uri         = $Uri
                Method      = $Method
                Headers     = $script:GraphHeaders
                ErrorAction = "Stop"
            }


            if ($null -ne $Body) {

                $Parameters["Body"] =
                    $Body |
                    ConvertTo-Json -Depth 20

                $Parameters["ContentType"] =
                    "application/json"
            }


            return Invoke-RestMethod @Parameters
        }
        catch {

            $StatusCode = 0


            try {

                $StatusCode =
                    [int]$_.Exception.Response.StatusCode
            }
            catch {
            }


            # ---------------------------------------------------------
            # Expected 404
            # ---------------------------------------------------------

            if (
                $AllowNotFound -and
                $StatusCode -eq 404
            ) {

                return $null
            }


            # ---------------------------------------------------------
            # Retry throttling / temporary failures
            # ---------------------------------------------------------

            if (
                $StatusCode -in @(
                    429,
                    500,
                    502,
                    503,
                    504
                )
            ) {

                $Delay =
                    [math]::Min(
                        60,
                        [math]::Pow(
                            2,
                            $Attempt
                        )
                    )


                Write-Log `
                    -Level "WARNING" `
                    -Message "Graph HTTP $StatusCode. Attempt $Attempt/$MaxRetries. Retrying in $Delay seconds."


                Start-Sleep `
                    -Seconds $Delay


                continue
            }


            # ---------------------------------------------------------
            # Detailed Graph error
            # ---------------------------------------------------------

            Write-Log `
                -Level "ERROR" `
                -Message "Microsoft Graph request failed."


            Write-Log `
                -Level "ERROR" `
                -Message "HTTP Status : $StatusCode"


            Write-Log `
                -Level "ERROR" `
                -Message "Method      : $Method"


            Write-Log `
                -Level "ERROR" `
                -Message "URI         : $Uri"


            Write-Log `
                -Level "ERROR" `
                -Message "Exception   : $($_.Exception.Message)"


            if ($_.ErrorDetails.Message) {

                Write-Log `
                    -Level "ERROR" `
                    -Message "Graph Response: $($_.ErrorDetails.Message)"
            }


            throw
        }
    }


    throw "Graph request failed after $MaxRetries attempts."
}


# =============================================================================
# GRAPH PAGINATION
# =============================================================================

function Get-GraphPaged {

    param (

        [Parameter(Mandatory)]
        [string]$Uri
    )


    $Results = @()


    do {

        $Response =
            Invoke-GraphRequest `
                -Uri $Uri `
                -Method GET


        if (
            $null -ne
            $Response.value
        ) {

            $Results +=
                @(
                    $Response.value
                )
        }


        $Uri =
            $Response.'@odata.nextLink'

    }
    while ($Uri)


    return @(
        $Results
    )
}


# =============================================================================
# JWT TOKEN DECODER
# =============================================================================

function Get-JwtPayload {

    param (

        [Parameter(Mandatory)]
        [string]$Token
    )


    try {

        $Parts =
            $Token.Split(".")


        if (
            $Parts.Count -lt 2
        ) {

            throw "Invalid JWT token."
        }


        $Payload =
            $Parts[1]


        $Payload =
            $Payload.Replace(
                "-",
                "+"
            ).Replace(
                "_",
                "/"
            )


        switch (
            $Payload.Length % 4
        ) {

            2 {

                $Payload += "=="
            }

            3 {

                $Payload += "="
            }
        }


        $Bytes =
            [Convert]::FromBase64String(
                $Payload
            )


        $Json =
            [System.Text.Encoding]::UTF8.GetString(
                $Bytes
            )


        return $Json |
            ConvertFrom-Json
    }
    catch {

        Write-Log `
            -Level "WARNING" `
            -Message "Unable to decode Graph token: $($_.Exception.Message)"


        return $null
    }
}


# =============================================================================
# FIND ENTRA DEVICE
# =============================================================================

function Find-EntraDeviceByDeviceId {

    param (

        [Parameter(Mandatory)]
        [string]$DeviceId
    )


    if (
        [string]::IsNullOrWhiteSpace(
            $DeviceId
        )
    ) {

        return $null
    }


    $Filter =
        [System.Uri]::EscapeDataString(
            "deviceId eq '$DeviceId'"
        )


    $Uri =
        "https://graph.microsoft.com/v1.0/devices?" +
        "`$filter=$Filter&" +
        "`$select=id,deviceId,displayName,accountEnabled"


    try {

        $Response =
            Invoke-GraphRequest `
                -Uri $Uri `
                -Method GET


        $Devices =
            @(
                $Response.value
            )


        if (
            $Devices.Count -eq 1
        ) {

            return $Devices[0]
        }


        if (
            $Devices.Count -gt 1
        ) {

            Write-Log `
                -Level "WARNING" `
                -Message "Multiple Entra devices found for Device ID: $DeviceId"


            return $null
        }


        return $null
    }
    catch {

        Write-Log `
            -Level "WARNING" `
            -Message "Unable to find Entra device for Device ID: $DeviceId"


        return $null
    }
}


# =============================================================================
# SECURE BOOT STATE CACHE
#
# Prevents querying the same device twice during the same job.
# =============================================================================

$script:SecureBootStateCache = @{}


# =============================================================================
# GET SECURE BOOT STATE FOR MANAGED DEVICE
# =============================================================================

function Get-DeviceSecureBootState {

    param (

        [Parameter(Mandatory)]
        [string]$ManagedDeviceId,

        [string]$DeviceName
    )


    # -------------------------------------------------------------------------
    # Return cached result
    # -------------------------------------------------------------------------

    if (
        $script:SecureBootStateCache.ContainsKey(
            $ManagedDeviceId
        )
    ) {

        return $script:SecureBootStateCache[
            $ManagedDeviceId
        ]
    }


    $Result =
        [PSCustomObject]@{

            DeviceName       = $DeviceName
            ManagedDeviceId  = $ManagedDeviceId

            PolicyFound      = $false
            SettingFound     = $false

            State            = $null
            CurrentValue     = $null

            PolicyStateId    = $null
            Setting          = $null
            SettingName      = $null
        }


    try {

        # =====================================================================
        # GET DEVICE COMPLIANCE POLICY STATES
        #
        # Beta API is required for the per-device policy/setting state.
        # =====================================================================

        $PolicyStateUri =
            "https://graph.microsoft.com/beta/" +
            "deviceManagement/managedDevices/" +
            "$ManagedDeviceId/" +
            "deviceCompliancePolicyStates"


        $PolicyStates =
            Get-GraphPaged `
                -Uri $PolicyStateUri


        # ---------------------------------------------------------------------
        # Match exact policy
        #
        # Use both ID and displayName for compatibility.
        # ---------------------------------------------------------------------

        $TargetPolicyStates =
            @(
                $PolicyStates |
                Where-Object {

                    (
                        $_.id -eq
                        $CompliancePolicyId
                    ) -or
                    (
                        ([string]$_.displayName).Trim() -eq
                        $CompliancePolicyName
                    )
                }
            )


        if (
            $TargetPolicyStates.Count -eq 0
        ) {

            Write-Log `
                -Level "INFO" `
                -Message "Compliance policy not found on device: $DeviceName"


            $script:SecureBootStateCache[
                $ManagedDeviceId
            ] = $Result


            return $Result
        }


        $TargetPolicyState =
            $TargetPolicyStates |
            Select-Object -First 1


        $Result.PolicyFound =
            $true


        $Result.PolicyStateId =
            $TargetPolicyState.id


        # =====================================================================
        # GET SETTING STATES FOR TARGET POLICY
        # =====================================================================

        $SettingStateUri =
            "https://graph.microsoft.com/beta/" +
            "deviceManagement/managedDevices/" +
            "$ManagedDeviceId/" +
            "deviceCompliancePolicyStates/" +
            "$($TargetPolicyState.id)/" +
            "settingStates"


        $SettingStates =
            Get-GraphPaged `
                -Uri $SettingStateUri


        # ---------------------------------------------------------------------
        # First try exact tenant setting name
        # ---------------------------------------------------------------------

        $SecureBootStates =
            @(
                $SettingStates |
                Where-Object {

                    ([string]$_.settingName).Trim() -eq
                    $SecureBootSettingName
                }
            )


        # ---------------------------------------------------------------------
        # Fallback: SecureBootEnabled suffix
        # ---------------------------------------------------------------------

        if (
            $SecureBootStates.Count -eq 0
        ) {

            $SecureBootStates =
                @(
                    $SettingStates |
                    Where-Object {

                        (
                            [string]$_.settingName -match
                            "(?i)SecureBootEnabled$"
                        ) -or
                        (
                            [string]$_.setting -match
                            "(?i)SecureBootEnabled$"
                        )
                    }
                )
        }


        if (
            $SecureBootStates.Count -eq 0
        ) {

            Write-Log `
                -Level "WARNING" `
                -Message "Secure Boot setting not found for device: $DeviceName"


            $script:SecureBootStateCache[
                $ManagedDeviceId
            ] = $Result


            return $Result
        }


        # ---------------------------------------------------------------------
        # Direct processing - first returned matching Secure Boot state
        #
        # No conservative/non-compliant-wins logic.
        # ---------------------------------------------------------------------

        $SecureBootState =
            $SecureBootStates |
            Select-Object -First 1


        $Result.SettingFound =
            $true


        $Result.State =
            $SecureBootState.state


        $Result.CurrentValue =
            $SecureBootState.currentValue


        $Result.Setting =
            $SecureBootState.setting


        $Result.SettingName =
            $SecureBootState.settingName


        $script:SecureBootStateCache[
            $ManagedDeviceId
        ] = $Result


        return $Result
    }
    catch {

        Write-Log `
            -Level "ERROR" `
            -Message "Unable to retrieve Secure Boot state for $DeviceName : $($_.Exception.Message)"


        $script:SecureBootStateCache[
            $ManagedDeviceId
        ] = $Result


        return $Result
    }
}


# =============================================================================
# START
# =============================================================================

Write-Output ""


Write-Log `
    -Message "============================================================"

Write-Log `
    -Message "SECURE BOOT COMPLIANCE GROUP AUTOMATION"

Write-Log `
    -Message "============================================================"


Write-Log `
    -Message "Policy Name         : $CompliancePolicyName"


Write-Log `
    -Message "Policy ID           : $CompliancePolicyId"


Write-Log `
    -Message "Secure Boot Setting : $SecureBootSettingName"


Write-Log `
    -Message "Target Group ID     : $TargetGroupId"


Write-Log `
    -Message "Dry Run             : $DryRun"


# =============================================================================
# GET AZURE AUTOMATION VARIABLES
# =============================================================================

try {

    Write-Log `
        -Message "Reading Azure Automation variables..."


    $TenantId =
        Get-AutomationVariable `
            -Name "Graph_TenantId"


    $ClientId =
        Get-AutomationVariable `
            -Name "Graph_ClientId"


    $ClientSecret =
        Get-AutomationVariable `
            -Name "Graph_ClientSecret"


    if (
        [string]::IsNullOrWhiteSpace(
            $TenantId
        )
    ) {

        throw "TenantId Automation variable is empty."
    }


    if (
        [string]::IsNullOrWhiteSpace(
            $ClientId
        )
    ) {

        throw "ClientId Automation variable is empty."
    }


    if (
        [string]::IsNullOrWhiteSpace(
            $ClientSecret
        )
    ) {

        throw "ClientSecret Automation variable is empty."
    }


    Write-Log `
        -Level "SUCCESS" `
        -Message "Automation variables loaded successfully."


    Write-Log `
        -Message "Tenant ID : $TenantId"


    Write-Log `
        -Message "Client ID : $ClientId"


    Write-Log `
        -Message "Client Secret loaded successfully. Value hidden."
}
catch {

    Write-Log `
        -Level "ERROR" `
        -Message "Unable to retrieve Automation variables."


    Write-Log `
        -Level "ERROR" `
        -Message $_.Exception.Message


    throw
}


# =============================================================================
# AUTHENTICATE TO MICROSOFT GRAPH
# =============================================================================

try {

    Write-Log `
        -Message "Requesting Microsoft Graph access token..."


    $TokenUri =
        "https://login.microsoftonline.com/" +
        "$TenantId/oauth2/v2.0/token"


    $TokenBody = @{

        client_id =
            $ClientId

        client_secret =
            $ClientSecret

        scope =
            "https://graph.microsoft.com/.default"

        grant_type =
            "client_credentials"
    }


    $TokenResponse =
        Invoke-RestMethod `
            -Uri $TokenUri `
            -Method POST `
            -Body $TokenBody `
            -ContentType "application/x-www-form-urlencoded" `
            -ErrorAction Stop


    $AccessToken =
        $TokenResponse.access_token


    if (
        [string]::IsNullOrWhiteSpace(
            $AccessToken
        )
    ) {

        throw "Graph token was not returned."
    }


    $script:GraphHeaders = @{

        Authorization =
            "Bearer $AccessToken"

        Accept =
            "application/json"
    }


    Write-Log `
        -Level "SUCCESS" `
        -Message "Microsoft Graph authentication successful."
}
catch {

    Write-Log `
        -Level "ERROR" `
        -Message "Microsoft Graph authentication FAILED."


    Write-Log `
        -Level "ERROR" `
        -Message $_.Exception.Message


    if (
        $_.ErrorDetails.Message
    ) {

        Write-Log `
            -Level "ERROR" `
            -Message $_.ErrorDetails.Message
    }


    throw
}


# =============================================================================
# VALIDATE GRAPH APPLICATION PERMISSIONS
# =============================================================================

$Claims =
    Get-JwtPayload `
        -Token $AccessToken


if ($Claims) {

    Write-Log `
        -Message "Validating Microsoft Graph permissions..."


    $RequiredPermissions = @(

        "DeviceManagementConfiguration.Read.All",

        "DeviceManagementManagedDevices.Read.All",

        "GroupMember.ReadWrite.All",

        "Device.ReadWrite.All"
    )


    $MissingPermissions =
        @()


    foreach (
        $Permission in
        $RequiredPermissions
    ) {

        if (
            $Claims.roles -contains
            $Permission
        ) {

            Write-Log `
                -Level "SUCCESS" `
                -Message "Permission Present: $Permission"
        }
        else {

            Write-Log `
                -Level "ERROR" `
                -Message "Permission MISSING: $Permission"


            $MissingPermissions +=
                $Permission
        }
    }


    if (
        $MissingPermissions.Count -gt 0
    ) {

        Write-Log `
            -Level "ERROR" `
            -Message "Missing permissions: $($MissingPermissions -join ', ')"


        throw "Required Graph permissions are missing."
    }


    Write-Log `
        -Level "SUCCESS" `
        -Message "All required Graph permissions are present."
}


# =============================================================================
# VALIDATE COMPLIANCE POLICY
# =============================================================================

Write-Log `
    -Message "Validating compliance policy..."


$PolicyUri =
    "https://graph.microsoft.com/v1.0/" +
    "deviceManagement/deviceCompliancePolicies/" +
    "$CompliancePolicyId"


try {

    $CompliancePolicy =
        Invoke-GraphRequest `
            -Uri $PolicyUri `
            -Method GET


    Write-Log `
        -Level "SUCCESS" `
        -Message "Compliance policy found: $($CompliancePolicy.displayName)"
}
catch {

    Write-Log `
        -Level "ERROR" `
        -Message "Unable to retrieve compliance policy."


    throw
}


# =============================================================================
# GET POLICY-SPECIFIC SETTING SUMMARIES
# =============================================================================

Write-Log `
    -Message "Retrieving policy-specific setting summaries..."


$PolicySettingUri =
    "https://graph.microsoft.com/v1.0/" +
    "deviceManagement/deviceCompliancePolicies/" +
    "$CompliancePolicyId/" +
    "deviceSettingStateSummaries"


try {

    $PolicySettings =
        Get-GraphPaged `
            -Uri $PolicySettingUri


    Write-Log `
        -Level "SUCCESS" `
        -Message "Policy setting summaries retrieved: $($PolicySettings.Count)"
}
catch {

    Write-Log `
        -Level "ERROR" `
        -Message "Unable to retrieve policy setting summaries."


    throw
}


# =============================================================================
# VALIDATE SECURE BOOT SETTING
# =============================================================================

$SecureBootSummary =
    @(
        $PolicySettings |
        Where-Object {

            ([string]$_.settingName).Trim() -eq
            $SecureBootSettingName
        }
    ) |
    Select-Object -First 1


if (
    -not $SecureBootSummary
) {

    Write-Log `
        -Level "ERROR" `
        -Message "Secure Boot setting not found under target compliance policy."


    Write-Output ""

    Write-Output "Settings returned by policy:"

    Write-Output ""


    $PolicySettings |
        Select-Object `
            id,
            settingName,
            compliantDeviceCount,
            nonCompliantDeviceCount,
            errorDeviceCount,
            unknownDeviceCount |
        Format-Table -AutoSize


    throw "Secure Boot setting was not found."
}


Write-Log `
    -Level "SUCCESS" `
    -Message "Secure Boot setting found successfully."


Write-Log `
    -Message "Setting Name          : $($SecureBootSummary.settingName)"


Write-Log `
    -Message "Setting Summary ID    : $($SecureBootSummary.id)"


Write-Log `
    -Message "Compliant Devices     : $($SecureBootSummary.compliantDeviceCount)"


Write-Log `
    -Message "Non-Compliant Devices : $($SecureBootSummary.nonCompliantDeviceCount)"


Write-Log `
    -Message "Error Devices         : $($SecureBootSummary.errorDeviceCount)"


Write-Log `
    -Message "Unknown Devices       : $($SecureBootSummary.unknownDeviceCount)"


# =============================================================================
# VALIDATE TARGET GROUP
# =============================================================================

# =============================================================================
# VALIDATE TARGET GROUP
# =============================================================================

Write-Log `
    -Message "Validating target Entra Security Group..."


# Remove accidental spaces
$TargetGroupId = $TargetGroupId.Trim()


# Validate GUID format before calling Graph
$ParsedGroupId = [Guid]::Empty

if (
    -not [Guid]::TryParse(
        $TargetGroupId,
        [ref]$ParsedGroupId
    )
) {

    throw "TargetGroupId is not a valid Entra Group Object ID: '$TargetGroupId'"
}


# Build Graph URI safely
$GroupUri =
    "https://graph.microsoft.com/v1.0/groups/${TargetGroupId}?`$select=id,displayName,securityEnabled,groupTypes,mailEnabled"


Write-Log `
    -Message "Group Graph URI: $GroupUri"


try {

    $TargetGroup =
        Invoke-GraphRequest `
            -Uri $GroupUri `
            -Method GET


    Write-Log `
        -Level "SUCCESS" `
        -Message "Target Group found."


    Write-Log `
        -Message "Group Name       : $($TargetGroup.displayName)"


    Write-Log `
        -Message "Group Object ID  : $($TargetGroup.id)"


    Write-Log `
        -Message "Security Enabled : $($TargetGroup.securityEnabled)"


    Write-Log `
        -Message "Mail Enabled     : $($TargetGroup.mailEnabled)"


    Write-Log `
        -Message "Group Types      : $($TargetGroup.groupTypes -join ', ')"


    # -------------------------------------------------------------------------
    # Dynamic group check
    # -------------------------------------------------------------------------

    if (
        $TargetGroup.groupTypes -contains
        "DynamicMembership"
    ) {

        throw @"
The target group is a Dynamic Membership group.

This script requires a Static / Assigned Security Group.
"@
    }


    # -------------------------------------------------------------------------
    # Security group check
    # -------------------------------------------------------------------------

    if (
        $TargetGroup.securityEnabled -ne
        $true
    ) {

        throw @"
The target group is not security enabled.

Please use an Entra Security Group with Assigned membership.
"@
    }


    Write-Log `
        -Level "SUCCESS" `
        -Message "Target group validation completed successfully."

}
catch {

    Write-Log `
        -Level "ERROR" `
        -Message "Target group validation failed."


    Write-Log `
        -Level "ERROR" `
        -Message "Target Group ID: $TargetGroupId"


    Write-Log `
        -Level "ERROR" `
        -Message "URI: $GroupUri"


    Write-Log `
        -Level "ERROR" `
        -Message "Exception: $($_.Exception.Message)"


    if (
        $_.ErrorDetails.Message
    ) {

        Write-Log `
            -Level "ERROR" `
            -Message "Graph Response: $($_.ErrorDetails.Message)"
    }


    throw
}


# =============================================================================
# GET ALL INTUNE MANAGED DEVICES
# =============================================================================

Write-Log `
    -Message "Retrieving Intune managed devices..."


$ManagedDevicesUri =
    "https://graph.microsoft.com/beta/" +
    "deviceManagement/managedDevices?" +
    "`$select=" +
    "id," +
    "deviceName," +
    "azureADDeviceId," +
    "operatingSystem," +
    "complianceState," +
    "lastSyncDateTime"


try {

    $ManagedDevices =
        Get-GraphPaged `
            -Uri $ManagedDevicesUri
}
catch {

    Write-Log `
        -Level "ERROR" `
        -Message "Unable to retrieve Intune managed devices."


    throw
}


$TotalManagedDevices =
    $ManagedDevices.Count


Write-Log `
    -Level "SUCCESS" `
    -Message "Total Intune managed devices: $TotalManagedDevices"


# =============================================================================
# WINDOWS DEVICES ONLY
# =============================================================================

$WindowsManagedDevices =
    @(
        $ManagedDevices |
        Where-Object {

            $_.operatingSystem -match
            "^Windows"
        }
    )


$WindowsDevices =
    $WindowsManagedDevices.Count


Write-Log `
    -Message "Windows managed devices: $WindowsDevices"


# =============================================================================
# BUILD INTUNE DEVICE LOOKUP USING AZURE AD DEVICE ID
# =============================================================================

$ManagedDeviceByAzureAdId =
    @{}


foreach (
    $Device in
    $WindowsManagedDevices
) {

    if (
        -not
        [string]::IsNullOrWhiteSpace(
            $Device.azureADDeviceId
        )
    ) {

        $Key =
            $Device.azureADDeviceId.ToLowerInvariant()


        $ManagedDeviceByAzureAdId[
            $Key
        ] =
            $Device
    }
}


# =============================================================================
# GET TARGET GROUP DEVICE MEMBERS
# =============================================================================

Write-Log `
    -Message "Retrieving current devices from target group..."


$GroupMembersUri =
    "https://graph.microsoft.com/v1.0/" +
    "groups/$TargetGroupId/" +
    "members/microsoft.graph.device?" +
    "`$select=id,deviceId,displayName&" +
    "`$top=999"


try {

    $CurrentGroupMembers =
        Get-GraphPaged `
            -Uri $GroupMembersUri


    Write-Log `
        -Level "SUCCESS" `
        -Message "Current device members in group: $($CurrentGroupMembers.Count)"
}
catch {

    Write-Log `
        -Level "ERROR" `
        -Message "Unable to retrieve group device members."


    throw
}


# =============================================================================
# BUILD GROUP MEMBER LOOKUP
# =============================================================================

$GroupMemberByObjectId =
    @{}


foreach (
    $Member in
    $CurrentGroupMembers
) {

    $GroupMemberByObjectId[
        $Member.id
    ] =
        $Member
}


# =============================================================================
# FIND OVERALL NON-COMPLIANT WINDOWS DEVICES
#
# These are candidates for addition.
#
# We DO NOT automatically add all of them.
# We inspect Secure Boot first.
# =============================================================================

$NonCompliantWindowsDevices =
    @(
        $WindowsManagedDevices |
        Where-Object {

            $_.complianceState -eq
            "noncompliant"
        }
    )


$OverallNonCompliant =
    $NonCompliantWindowsDevices.Count


Write-Log `
    -Message "Overall non-compliant Windows devices to inspect: $OverallNonCompliant"


# =============================================================================
# PHASE 1
# NON-COMPLIANT SECURE BOOT -> ADD TO GROUP
# =============================================================================

Write-Output ""

Write-Log `
    -Message "============================================================"

Write-Log `
    -Message "PHASE 1 - CHECKING DEVICES FOR SECURE BOOT NON-COMPLIANCE"

Write-Log `
    -Message "============================================================"


foreach (
    $Device in
    $NonCompliantWindowsDevices
) {

    Write-Output ""


    Write-Log `
        -Message "------------------------------------------------------------"


    Write-Log `
        -Message "Device Name       : $($Device.deviceName)"


    Write-Log `
        -Message "Intune Device ID  : $($Device.id)"


    Write-Log `
        -Message "Overall State     : $($Device.complianceState)"


    $SecureBoot =
        Get-DeviceSecureBootState `
            -ManagedDeviceId $Device.id `
            -DeviceName $Device.deviceName


    if (
        -not
        $SecureBoot.PolicyFound
    ) {

        $PolicyNotFoundCount++

        continue
    }


    if (
        -not
        $SecureBoot.SettingFound
    ) {

        $SettingNotFoundCount++

        continue
    }


    Write-Log `
        -Message "Secure Boot Setting : $($SecureBoot.SettingName)"


    Write-Log `
        -Message "Secure Boot State   : $($SecureBoot.State)"


    Write-Log `
        -Message "Current Value       : $($SecureBoot.CurrentValue)"


    # =========================================================================
    # ONLY ADD SECURE BOOT NON-COMPLIANT DEVICES
    # =========================================================================

    if (
        $SecureBoot.State -ne
        "nonCompliant"
    ) {

        Write-Log `
            -Level "INFO" `
            -Message "Device is not Secure Boot non-compliant. No add action."


        $NoActionCount++


        continue
    }


    $SecureBootNonCompliant++


    # =========================================================================
    # CHECK AZURE AD DEVICE ID
    # =========================================================================

    if (
        [string]::IsNullOrWhiteSpace(
            $Device.azureADDeviceId
        )
    ) {

        Write-Log `
            -Level "WARNING" `
            -Message "Azure AD Device ID is missing."


        $UnresolvedCount++


        continue
    }


    # =========================================================================
    # RESOLVE ENTRA OBJECT
    # =========================================================================

    $EntraDevice =
        Find-EntraDeviceByDeviceId `
            -DeviceId $Device.azureADDeviceId


    if (
        -not
        $EntraDevice
    ) {

        Write-Log `
            -Level "WARNING" `
            -Message "Unable to resolve Entra device."


        $UnresolvedCount++


        continue
    }


    Write-Log `
        -Level "SUCCESS" `
        -Message "Resolved Entra Device: $($EntraDevice.displayName)"


    Write-Log `
        -Message "Entra Object ID : $($EntraDevice.id)"


    $IsMember =
        $GroupMemberByObjectId.ContainsKey(
            $EntraDevice.id
        )


    # =========================================================================
    # ALREADY MEMBER
    # =========================================================================

    if ($IsMember) {

        Write-Log `
            -Level "INFO" `
            -Message "Device already exists in target group."


        $AlreadyMemberCount++


        continue
    }


    # =========================================================================
    # DRY RUN ADD
    # =========================================================================

if ($DryRun) {

    $WouldAddCount++

    Write-Log `
        -Level "WARNING" `
        -Message "DRY RUN: Would ADD Secure Boot non-compliant device: $($EntraDevice.displayName)"

    continue
}

    # =========================================================================
    # ADD DEVICE
    # =========================================================================

    try {

        $AddUri =
            "https://graph.microsoft.com/v1.0/" +
            "groups/$TargetGroupId/" +
            "members/`$ref"


        $Body = @{

            "@odata.id" =
                "https://graph.microsoft.com/v1.0/" +
                "directoryObjects/$($EntraDevice.id)"
        }


        Invoke-GraphRequest `
            -Uri $AddUri `
            -Method POST `
            -Body $Body |
            Out-Null


        Write-Log `
            -Level "SUCCESS" `
            -Message "ADDED Secure Boot non-compliant device: $($EntraDevice.displayName)"


        $GroupMemberByObjectId[
            $EntraDevice.id
        ] =
            $EntraDevice


        $AddedCount++
    }
    catch {

        Write-Log `
            -Level "ERROR" `
            -Message "Failed adding device: $($EntraDevice.displayName)"


        $ErrorCount++
    }
}


# =============================================================================
# PHASE 2
# CHECK EXISTING GROUP MEMBERS
#
# compliant / remediated Secure Boot -> REMOVE
# =============================================================================

Write-Output ""

Write-Log `
    -Message "============================================================"

Write-Log `
    -Message "PHASE 2 - CHECKING GROUP MEMBERS FOR REMOVAL"

Write-Log `
    -Message "============================================================"


foreach (
    $GroupDevice in
    $CurrentGroupMembers
) {

    Write-Output ""


    Write-Log `
        -Message "------------------------------------------------------------"


    Write-Log `
        -Message "Group Device: $($GroupDevice.displayName)"


    if (
        [string]::IsNullOrWhiteSpace(
            $GroupDevice.deviceId
        )
    ) {

        Write-Log `
            -Level "WARNING" `
            -Message "Group device does not have an Entra Device ID."


        $UnresolvedCount++


        continue
    }


    $LookupKey =
        $GroupDevice.deviceId.ToLowerInvariant()


    # =========================================================================
    # FIND INTUNE DEVICE
    # =========================================================================

    if (
        -not
        $ManagedDeviceByAzureAdId.ContainsKey(
            $LookupKey
        )
    ) {

        Write-Log `
            -Level "WARNING" `
            -Message "Unable to find matching Intune managed device. No removal performed."


        $UnresolvedCount++


        continue
    }


    $ManagedDevice =
        $ManagedDeviceByAzureAdId[
            $LookupKey
        ]


    Write-Log `
        -Message "Intune Device ID: $($ManagedDevice.id)"


    # =========================================================================
    # GET SECURE BOOT STATE
    # =========================================================================

    $SecureBoot =
        Get-DeviceSecureBootState `
            -ManagedDeviceId $ManagedDevice.id `
            -DeviceName $ManagedDevice.deviceName


    if (
        -not
        $SecureBoot.PolicyFound
    ) {

        Write-Log `
            -Level "INFO" `
            -Message "Target compliance policy not found. No removal."


        $PolicyNotFoundCount++


        continue
    }


    if (
        -not
        $SecureBoot.SettingFound
    ) {

        Write-Log `
            -Level "INFO" `
            -Message "Secure Boot setting not found. No removal."


        $SettingNotFoundCount++


        continue
    }


    Write-Log `
        -Message "Secure Boot State : $($SecureBoot.State)"


    Write-Log `
        -Message "Current Value     : $($SecureBoot.CurrentValue)"


    # =========================================================================
    # NON-COMPLIANT -> KEEP
    # =========================================================================

    if (
        $SecureBoot.State -eq
        "nonCompliant"
    ) {

        Write-Log `
            -Level "INFO" `
            -Message "Secure Boot is still non-compliant. Device remains in group."


        continue
    }


    # =========================================================================
    # OTHER STATES -> NO ACTION
    # =========================================================================

    if (
        $SecureBoot.State -notin @(
            "compliant",
            "remediated"
        )
    ) {

        Write-Log `
            -Level "INFO" `
            -Message "State $($SecureBoot.State) does not require removal."


        $NoActionCount++


        continue
    }


    $SecureBootCompliant++


    # =========================================================================
    # DRY RUN REMOVE
    # =========================================================================

if ($DryRun) {

    $WouldRemoveCount++

    Write-Log `
        -Level "WARNING" `
        -Message "DRY RUN: Would REMOVE Secure Boot compliant device: $($GroupDevice.displayName)"

    continue
}


    # =========================================================================
    # REMOVE GROUP MEMBERSHIP
    # =========================================================================

    try {

        $RemoveUri =
            "https://graph.microsoft.com/v1.0/" +
            "groups/$TargetGroupId/" +
            "members/$($GroupDevice.id)/" +
            "`$ref"


        Invoke-GraphRequest `
            -Uri $RemoveUri `
            -Method DELETE |
            Out-Null


        Write-Log `
            -Level "SUCCESS" `
            -Message "REMOVED Secure Boot compliant device: $($GroupDevice.displayName)"


        $RemovedCount++
    }
    catch {

        Write-Log `
            -Level "ERROR" `
            -Message "Failed removing device: $($GroupDevice.displayName)"


        $ErrorCount++
    }
}


# =============================================================================
# FINAL SUMMARY
# =============================================================================

Write-Output ""
Write-Output ""


Write-Log `
    -Message "============================================================"

Write-Log `
    -Message "SECURE BOOT AUTOMATION SUMMARY"

Write-Log `
    -Message "============================================================"


Write-Log `
    -Message "Policy Name                  : $CompliancePolicyName"


Write-Log `
    -Message "Secure Boot Setting          : $SecureBootSettingName"


Write-Log `
    -Message "Total Intune Devices         : $TotalManagedDevices"


Write-Log `
    -Message "Windows Devices              : $WindowsDevices"


Write-Log `
    -Message "Overall Non-Compliant        : $OverallNonCompliant"


Write-Log `
    -Message "Secure Boot Non-Compliant    : $SecureBootNonCompliant"


Write-Log `
    -Message "Secure Boot Compliant        : $SecureBootCompliant"


Write-Log `
    -Message "Devices Added                : $AddedCount"


Write-Log `
    -Message "Devices Removed              : $RemovedCount"


Write-Log `
    -Message "Already Group Members        : $AlreadyMemberCount"


Write-Log `
    -Message "Policy Not Found             : $PolicyNotFoundCount"


Write-Log `
    -Message "Secure Boot Setting Not Found: $SettingNotFoundCount"


Write-Log `
    -Message "Unresolved Devices           : $UnresolvedCount"


Write-Log `
    -Message "No Action                    : $NoActionCount"


Write-Log `
    -Message "Errors                       : $ErrorCount"


Write-Log `
    -Message "DryRun                       : $DryRun"

Write-Log `
    -Message "Would Add (DryRun)            : $WouldAddCount"

Write-Log `
    -Message "Would Remove (DryRun)         : $WouldRemoveCount"


Write-Log `
    -Message "============================================================"


if ($DryRun) {

    Write-Log `
        -Level "WARNING" `
        -Message "DRY RUN completed. No group membership changes were made."
}
else {

    Write-Log `
        -Level "SUCCESS" `
        -Message "Secure Boot compliance automation completed."
}


Write-Output ""

