<#
.SYNOPSIS
Adds eligible devices owned by members of licensed-user groups to static device groups.
.NOTES
Azure Automation PowerShell 7.2. Add-only: this runbook never removes group members.
#>
[CmdletBinding()]
param(
    [bool]$DryRun = $true,
    [string]$MappingsJson = '',
    [ValidateRange(1,20)][int]$MaxRetryCount = 6
)

$ErrorActionPreference = 'Stop'
$GraphBase = 'https://graph.microsoft.com/v1.0'

function Get-ManagedIdentityToken {
    if ([string]::IsNullOrWhiteSpace($env:IDENTITY_ENDPOINT) -or [string]::IsNullOrWhiteSpace($env:IDENTITY_HEADER)) {
        throw 'Azure Automation managed identity endpoint was not found. Enable the Automation Account system-assigned identity.'
    }
    $uri = $env:IDENTITY_ENDPOINT + '?resource=https%3A%2F%2Fgraph.microsoft.com%2F&api-version=2019-08-01'
    (Invoke-RestMethod -Method GET -Uri $uri -Headers @{ 'X-IDENTITY-HEADER' = $env:IDENTITY_HEADER }).access_token
}

function Invoke-Graph {
    param(
        [Parameter(Mandatory)][ValidateSet('GET','POST')][string]$Method,
        [Parameter(Mandatory)][string]$Uri,
        [object]$Body
    )
    for ($attempt = 0; $attempt -le $MaxRetryCount; $attempt++) {
        try {
            $params = @{ Method=$Method; Uri=$Uri; Headers=@{Authorization="Bearer $script:Token";Accept='application/json'}; ErrorAction='Stop' }
            if ($null -ne $Body) { $params.ContentType='application/json'; $params.Body=($Body | ConvertTo-Json -Depth 10 -Compress) }
            return Invoke-RestMethod @params
        } catch {
            $status = [int]$_.Exception.Response.StatusCode
            if ($attempt -eq $MaxRetryCount -or $status -notin 429,500,502,503,504) { throw }
            $retryAfter = $_.Exception.Response.Headers.RetryAfter.Delta.TotalSeconds
            if (-not $retryAfter) { $retryAfter = [math]::Min(60, [math]::Pow(2,$attempt) + (Get-Random -Minimum 0 -Maximum 3)) }
            Write-Warning "Graph returned HTTP $status. Retrying in $retryAfter second(s)."
            Start-Sleep -Seconds $retryAfter
        }
    }
}

function Get-AllPages([string]$FirstUrl) {
    $url = $FirstUrl
    while ($url) {
        $response = Invoke-Graph -Method GET -Uri $url
        @($response.value) | ForEach-Object { $_ }
        $url = $response.'@odata.nextLink'
    }
}

function Assert-Guid([string]$Value,[string]$Label) {
    $parsed = [guid]::Empty
    if (-not [guid]::TryParse($Value,[ref]$parsed)) { throw "$Label is not a valid GUID." }
}

if ([string]::IsNullOrWhiteSpace($MappingsJson)) {
    $MappingsJson = Get-AutomationVariable -Name 'DeviceGroupMappingsJson'
}
$mappings = @($MappingsJson | ConvertFrom-Json) | Where-Object { $_.enabled -ne $false }
if ($mappings.Count -eq 0) { throw 'No enabled mappings were supplied.' }

$script:Token = Get-ManagedIdentityToken
if (-not $script:Token) { throw 'Managed identity did not return a Graph token.' }

$deviceCache = @{}
$failures = [System.Collections.Generic.List[string]]::new()
$totalAdded = 0

foreach ($mapping in $mappings) {
    try {
        Assert-Guid ([string]$mapping.sourceUserGroupId) "sourceUserGroupId for '$($mapping.name)'"
        Assert-Guid ([string]$mapping.targetDeviceGroupId) "targetDeviceGroupId for '$($mapping.name)'"
        Write-Output "[$($mapping.name)] Starting (DryRun=$DryRun)."

        $target = Invoke-Graph GET "$GraphBase/groups/$($mapping.targetDeviceGroupId)?`$select=id,displayName,securityEnabled,mailEnabled,groupTypes"
        if (-not $target.securityEnabled -or $target.mailEnabled -or @($target.groupTypes) -contains 'DynamicMembership') {
            throw "Target '$($target.displayName)' must be a static, non-mail-enabled security group."
        }

        $users = @(Get-AllPages "$GraphBase/groups/$($mapping.sourceUserGroupId)/transitiveMembers/microsoft.graph.user?`$select=id,userPrincipalName")
        $desired = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
        foreach ($user in $users) {
            if (-not $deviceCache.ContainsKey($user.id)) {
                $eligible = [System.Collections.Generic.List[string]]::new()
                $devices = @(Get-AllPages "$GraphBase/users/$($user.id)/registeredDevices/microsoft.graph.device?`$select=id,displayName,operatingSystem,deviceOwnership,isManaged,isCompliant")
                foreach ($device in $devices) {
                    if ($device.operatingSystem -ne 'Windows' -or $device.deviceOwnership -ne 'Company' -or $device.isManaged -ne $true -or $device.isCompliant -ne $true) { continue }
                    $owners = @(Get-AllPages "$GraphBase/devices/$($device.id)/registeredOwners?`$select=id")
                    if ($owners.Count -eq 1 -and $owners[0].id -eq $user.id) { $eligible.Add([string]$device.id) }
                }
                $deviceCache[$user.id] = @($eligible)
            }
            foreach ($id in $deviceCache[$user.id]) { [void]$desired.Add($id) }
        }

        $current = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
        Get-AllPages "$GraphBase/groups/$($mapping.targetDeviceGroupId)/members/microsoft.graph.device?`$select=id" | ForEach-Object { [void]$current.Add([string]$_.id) }
        $toAdd = @($desired | Where-Object { -not $current.Contains($_) })
        foreach ($deviceId in $toAdd) {
            if ($DryRun) { Write-Output "[$($mapping.name)] WOULD ADD device $deviceId"; continue }
            $refUri = "$GraphBase/groups/$($mapping.targetDeviceGroupId)/members/" + '$ref'
            Invoke-Graph POST $refUri @{ '@odata.id'="$GraphBase/directoryObjects/$deviceId" } | Out-Null
            Write-Output "[$($mapping.name)] ADDED device $deviceId"
            $totalAdded++
        }
        Write-Output "[$($mapping.name)] Users=$($users.Count); EligibleDevices=$($desired.Count); Missing=$($toAdd.Count)."
    } catch {
        $message = "[$($mapping.name)] $($_.Exception.Message)"
        $failures.Add($message)
        Write-Error $message -ErrorAction Continue
    }
}

Write-Output "Completed. Mappings=$($mappings.Count); Added=$totalAdded; Failures=$($failures.Count); DryRun=$DryRun."
if ($failures.Count -gt 0) { throw ($failures -join [Environment]::NewLine) }
