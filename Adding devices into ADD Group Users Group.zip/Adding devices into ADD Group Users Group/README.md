# Entra user-to-device application deployment automation

This project keeps static Microsoft Entra device groups populated from licensed-user groups. Assign each Intune application to its target **device** group; the Azure Automation runbook then adds every qualifying device owned by a user in the matching source group.

The solution is intentionally **add-only**. It never removes an existing device from a target group.

## Flow

1. Read one or more source-user-group / target-device-group mappings.
2. Expand nested user-group membership.
3. Find each user's registered Windows devices.
4. Keep only company-owned, managed, compliant devices whose sole registered owner is that user.
5. Add missing devices to the mapped static security group.
6. Intune deploys the application already assigned to that device group.

> Licensing is represented by membership of the source user group. The runbook does not query Microsoft 365 SKU/service-plan assignments and does not install software itself.

## Files

- `runbook/Sync-LicensedUserDevices.ps1` – production PowerShell 7.2 runbook
- `config/mappings.example.json` – Office, Visio, Project, and extensible mapping format
- `scripts/Test-MappingConfig.ps1` – local configuration validation
- `docs/DEPLOYMENT.md` – Azure Automation, Graph permission, Intune, test, and rollout guide

## Quick start

1. Create static, security-enabled Entra device groups for each application.
2. Copy `config/mappings.example.json`, replace every placeholder GUID, and validate it:

   ```powershell
   ./scripts/Test-MappingConfig.ps1 -Path ./config/mappings.json
   ```

3. Create an Azure Automation Account with a system-assigned managed identity and a PowerShell 7.2 runbook.
4. Grant the identity the Graph **application** permissions listed in `docs/DEPLOYMENT.md` and grant tenant admin consent.
5. Store the compact JSON as an Automation variable named `DeviceGroupMappingsJson`.
6. Import/publish the runbook and run it first with `-DryRun $true`.
7. Assign each Intune app as **Required** to its corresponding target device group, then schedule the runbook (for example, hourly).

## Important behavior

- Nested source groups are supported through `transitiveMembers`.
- Target groups must be static security groups; Microsoft 365 and dynamic groups are rejected.
- Graph throttling and temporary server errors are retried.
- Mapping failures are isolated; the job continues and fails at the end with a summary.
- Duplicate target groups across mappings are supported.
- No client secret is stored. Managed identity is the default and recommended authentication method.

