# Deployment guide

## 1. Prepare Entra and Intune groups

For every licensed application, use:

- one source **user** security group representing licensed/approved users;
- one target **static device** security group populated by this runbook.

Create mappings in the JSON configuration. Assign the corresponding Intune Win32 or Microsoft 365 app as **Required** to the target device group. Keep Visio and Project deployment configuration compatible with the installed Microsoft 365 Apps architecture, update channel, and language.

## 2. Create Azure Automation

1. Create an Automation Account in the desired subscription/resource group.
2. Enable **System assigned** identity under **Identity**.
3. Create a **PowerShell 7.2** runbook named `Sync-LicensedUserDevices`.
4. Import `runbook/Sync-LicensedUserDevices.ps1`, save, and publish it.
5. Create an encrypted Automation variable named `DeviceGroupMappingsJson`. Paste compact JSON based on `config/mappings.example.json`.

The JSON contains group object IDs, not names. It is not secret, but marking the variable encrypted prevents casual disclosure in the portal.

## 3. Grant Microsoft Graph application permissions

Grant these Microsoft Graph **application permissions** to the Automation Account managed identity, then grant tenant-wide admin consent:

- `GroupMember.Read.All` – read transitive users and current group members;
- `Device.Read.All` – read devices and registered owners;
- `GroupMember.ReadWrite.All` – add devices to target groups.

Your tenant may require `Directory.Read.All` if its policies or Graph authorization behavior do not allow all required directory-object reads with the permissions above. Start with the narrower set and add it only after validating a documented 403 response.

An Entra administrator can grant app roles with Microsoft Entra PowerShell or Microsoft Graph. Record the Automation Account identity's **Object (principal) ID**, verify the enterprise application, and have a Privileged Role Administrator (or other suitably authorized role) approve consent. Azure RBAC roles on the subscription do not grant Microsoft Graph directory permissions.

## 4. Test safely

Run with:

```powershell
-DryRun $true
```

Confirm the job output lists expected `WOULD ADD` device IDs. Test with a small pilot source group, verify the devices in Entra/Intune, then run:

```powershell
-DryRun $false
```

The runbook validates that target groups are static, non-mail-enabled security groups. It never removes devices.

## 5. Schedule and operate

- Link a recurring schedule, normally every 1–4 hours depending on license-to-install urgency.
- Set the scheduled parameter `DryRun` to `false` only after pilot approval.
- Create an Azure Monitor alert for failed Automation jobs.
- Review failures for Graph 403 (permissions), 404 (wrong group ID), and 429 (sustained throttling).
- Periodically review stale devices manually because add-only mode deliberately does not clean them up.

## Eligibility rules

A device is added only when all are true:

- `operatingSystem` is `Windows`;
- `deviceOwnership` is `Company`;
- `isManaged` and `isCompliant` are true;
- the user is the device's only registered owner.

These are Entra device properties, not an assertion that the device is online. Newly enrolled devices can take time to become compliant and will be picked up by a later run.

## Adding another licensed application

Create its target static device group, add one JSON object with a unique name and the source/target group IDs, update the Automation variable, assign the app to the target group in Intune, and run a dry-run job. No runbook code change is required.

## Rollback

Unlink/disable the schedule or set scheduled execution back to dry-run. Because the automation is add-only, rollback of memberships is a deliberate administrator action: remove only the devices confirmed to have been added for the affected application group.
