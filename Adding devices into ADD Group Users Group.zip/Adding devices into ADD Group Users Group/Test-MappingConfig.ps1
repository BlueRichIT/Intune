[CmdletBinding()]
param([Parameter(Mandatory)][string]$Path)

$ErrorActionPreference = 'Stop'
$items = @(Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json)
if ($items.Count -eq 0) { throw 'The mapping array is empty.' }

$names = @{}
foreach ($item in $items) {
    foreach ($field in 'name','sourceUserGroupId','targetDeviceGroupId') {
        if ([string]::IsNullOrWhiteSpace([string]$item.$field)) { throw "Missing '$field' in a mapping." }
    }
    if (-not [guid]::TryParse([string]$item.sourceUserGroupId, [ref]([guid]::Empty))) { throw "Invalid sourceUserGroupId for '$($item.name)'." }
    if (-not [guid]::TryParse([string]$item.targetDeviceGroupId, [ref]([guid]::Empty))) { throw "Invalid targetDeviceGroupId for '$($item.name)'." }
    if ($names.ContainsKey([string]$item.name)) { throw "Duplicate mapping name '$($item.name)'." }
    $names[[string]$item.name] = $true
}
Write-Host "Valid configuration: $($items.Count) mapping(s)."
